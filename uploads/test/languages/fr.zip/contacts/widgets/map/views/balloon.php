<div>
<?= $data->balloon_content_body;?>
</div>