<?php

return array(
    'NAME' => 'ФИО',
    'EMAIL' => 'E-mail',
    'MSG' => 'Сообщение',
    'VERIFYCODE' => 'Код',
    'PHONE' => 'Телефон',
);
?>
