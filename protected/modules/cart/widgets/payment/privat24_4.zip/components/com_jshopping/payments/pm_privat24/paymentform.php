<?php defined('_JEXEC') or die(); ?>
<script type="text/javascript">
function check_pm_privat24(){
    jQuery('#payment_form').submit();
}
</script>