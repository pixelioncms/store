<?php
// Privat24
define('_JSHOP_PRIVAT24_MERCHANT_ID','Номер мерчанта:');
define('_JSHOP_PRIVAT24_MERCHANT_PASS','Пароль мерчанта:');
define('_JSHOP_PRIVAT24_TRANSACTION_END_DESCRIPTION','Виберіть статус замовлення, який буде встановлений, якщо Privat24 транзакція пройшла успішно.');
define('_JSHOP_PRIVAT24_TRANSACTION_PENDING_DESCRIPTION','Виберіть статус замовлення, який буде встановлений, якщо Privat24 транзакція незавершена.');
define('_JSHOP_PRIVAT24_TRANSACTION_FAILED_DESCRIPTION','Виберіть статус замовлення, який буде встановлений, якщо Privat24 транзакція пройшла неуспішно.');
define('_JSHOP_PRIVAT24_CHECK_DATA_RETURN','Перевіряти дані Privat24 після повернення');
?>
