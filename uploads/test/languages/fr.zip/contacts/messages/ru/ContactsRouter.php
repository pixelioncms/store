<?php

return array(
    'NAME' => 'Содержание маркера',
    'START_COORDS' => 'Координаты точки А',
    'END_COORDS' => 'Координаты точки Б',
    'MAP_ID' => 'На какой карте маршрут будет',
    'TAB_GENERAL' => 'Основной',
    'TAB_START' => 'Точка А',
    'TAB_END' => 'Точка Б',
    'COLOR' => 'Цвет линии маршрута',
    'START_BALLOON_CONTENT_BODY' => 'Содержание балуна',
    'END_BALLOON_CONTENT_BODY' => 'Содержание балуна',
    'PRESET' => 'Cтиль точкки А и B',
    'HINT_PRESET' => 'см. список здесь: {link}',
    'START_ICON_CONTENT' => 'Содержание точки',
    'END_ICON_CONTENT' => 'Содержание точки',
    'OPACITY' => 'Прозрачность линии маршрута',
    'MAPSTATEAUTOAPPLY' => 'Автоматически позиционировать карту'
);
?>
