<?php if($type=='block'){ ?>

<div id="side-phone">
<p>Телефоны в Одессе:</p>
<?php foreach($model as $row){ ?>
<p><span><?= $row->phones ?></span></p>
<?php } ?>
</div>

<?php }else{ ?>

<div id="phone">
<p>Телефоны в Одессе:</p>
<?php foreach($model as $row){ ?>
<p><?= $row->name ?><span><?= $row->phones ?></span></p>
<?php } ?>
</div>

<?php } ?>
                        <div class="contact-information">
                                <div class="module-heading">
                                    <h4 class="module-title">information</h4>
                                </div><!-- /.module-heading -->

                                <div class="module-body outer-top-xs">
                                    <ul class="toggle-footer" style="">
                                        <li class="media">
                                            <div class="pull-left">
                                                <span class="icon fa-stack fa-lg">
                                                    <i class="fa fa-circle fa-stack-2x"></i>
                                                    <i class="fa fa-map-marker fa-stack-1x fa-inverse"></i>
                                                </span>
                                            </div>
                                            <div class="media-body">
                                                <p>868 Any Stress,Burala Casi,Picasa USA.</p>
                                            </div>
                                        </li>

                                        <li class="media">
                                            <div class="pull-left">
                                                <span class="icon fa-stack fa-lg">
                                                    <i class="fa fa-circle fa-stack-2x"></i>
                                                    <i class="fa fa-mobile fa-stack-1x fa-inverse"></i>
                                                </span>
                                            </div>
                                            <div class="media-body">
                                                <p>(400) 0888 888 888<br>(400) 888 888 888</p>
                                            </div>
                                        </li>

                                        <li class="media">
                                            <div class="pull-left">
                                                <span class="icon fa-stack fa-lg">
                                                    <i class="fa fa-circle fa-stack-2x"></i>
                                                    <i class="fa fa-envelope fa-stack-1x fa-inverse"></i>
                                                </span>
                                            </div>
                                            <div class="media-body">
                                                <span><a href="#">Contact @Unicase.com</a></span><br>
                                                <span><a href="#">Sale @Unicase.com</a></span>
                                            </div>
                                        </li>

                                    </ul>
                                </div><!-- /.module-body -->
                            </div><!-- /.contact-timing -->