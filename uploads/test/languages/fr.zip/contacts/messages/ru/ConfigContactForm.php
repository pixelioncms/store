<?php

return array(
    'FORM_EMAILS' => 'E-mail на которую будет отправлено письмо с формы обратной связи',
    'TEMPMESSAGE' => 'Шаблон письма',
    'TAB_FB' => 'Обратная связь',
    'TAB_SEO' => 'Мета данные',
    'TAB_GENERAL' => 'Контактные данные',
    'SKYPE' => 'Skype',
    'ADDRESS' => 'Адрес',
    'PHONE' => 'Телефон',
    'ENABLE_CAPTCHA'=>'Активировать капчу'
);