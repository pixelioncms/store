<?php

class DefaultController extends Controller {

    public function actions() {
        return array(
            'captcha' => array(
                'class' => 'CCaptchaAction',
                'testLimit' => '1',
            ),
        );
    }
    public function actionGetAddressList() {
        $data = $_POST['data'];

        $model = ContactsAddress::model()
                //->published()
                ->findAllByAttributes(array('city_id'=>$data['index']));
        $address = array();
        if ($model) {
            $address['success']=true;
            foreach ($model as $addr) {
                $coord = explode(',', $addr->coords);
                $address['address'][] = array(
                    'name' => $addr->name,
                    'coordx' => (float)$coord[1],
                    'coordy' => (float)$coord[0],
                    'weekdays_time'=>$addr->weekdays_time,
                    'weekend_time'=>$addr->weekend_time
                );
            }
        } else {
            $address['success'] = false;
            $address['message']='у нас нет представительств в этом городе';
        }


        echo CJSON::encode($address);
        die;
        //$this->render('address_list', array('model' => $model));
    }
    public function actionIndex() {
        $this->breadcrumbs = array(Yii::t('ContactsModule.default', 'MODULE_NAME'));
        $model = new ContactForm;
        $this->performAjaxValidation($model, 'contact_form');

        if (isset($_POST['ContactForm'])) {
            $model->attributes = $_POST['ContactForm'];
            if (Yii::app()->request->isPostRequest && $model->validate()) {

                $model->sendMessage();
                $model->unsetAttributes();
                Yii::app()->user->setFlash('success', Yii::t('ContactsModule.default', 'MESSAGE_SUCCESS'));
                //  $this->addFlashMessage(Yii::t('ContactsModule.default', 'MESSAGE_SUCCESS'));
            } else {
                //$this->addFlashMessage(Yii::t('ContactsModule.default', 'MESSAGE_FAIL'));
                Yii::app()->user->setFlash('error', Yii::t('ContactsModule.default', 'MESSAGE_FAIL'));
            }
        }
        $this->render('index', array('model' => $model, 'config' => $config));
    }

}
