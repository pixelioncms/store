<?php
// Privat24
define('_JSHOP_PRIVAT24_MERCHANT_ID','Merchant ID:');
define('_JSHOP_PRIVAT24_MERCHANT_PASS','Merchant password:');
define('_JSHOP_PRIVAT24_TRANSACTION_END_DESCRIPTION','Select the order status to which the actual order is set, if the Privat24 IPN was successful.');
define('_JSHOP_PRIVAT24_TRANSACTION_PENDING_DESCRIPTION','The order Status to which Orders are set, which have no completed Privat24 Transaction.');
define('_JSHOP_PRIVAT24_TRANSACTION_FAILED_DESCRIPTION','Select an order status for failed Privat24 transactions.');
define('_JSHOP_PRIVAT24_CHECK_DATA_RETURN','Check data Privat24 RETURN');
?>