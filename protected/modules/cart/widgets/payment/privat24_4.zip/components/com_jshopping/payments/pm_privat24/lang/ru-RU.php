<?php
// Privat24
define('_JSHOP_PRIVAT24_MERCHANT_ID','Номер мерчанта:');
define('_JSHOP_PRIVAT24_MERCHANT_PASS','Пароль мерчанта:');
define('_JSHOP_PRIVAT24_TRANSACTION_END_DESCRIPTION','Выберите статус заказа, который будет установлен, если Privat24 транзакция прошла успешно.');
define('_JSHOP_PRIVAT24_TRANSACTION_PENDING_DESCRIPTION','Выберите статус заказа, который будет установлен, если Privat24 транзакция незавершена.');
define('_JSHOP_PRIVAT24_TRANSACTION_FAILED_DESCRIPTION','Выберите статус заказа, который будет установлен, если Privat24 транзакция прошла неуспешно.');
define('_JSHOP_PRIVAT24_CHECK_DATA_RETURN','Проверять данные Privat24 после возврата');
?>