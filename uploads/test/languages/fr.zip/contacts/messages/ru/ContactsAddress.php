<?php

return array(
    'NAME' => 'Адрес',
    'COORDS' => 'Координаты на карте',
    'CITY_ID' => 'Город',
    'WEEKDAYS_TIME' => 'Время работы (будние)',
    'WEEKEND_TIME' => 'Время работы (выходные)',
);
