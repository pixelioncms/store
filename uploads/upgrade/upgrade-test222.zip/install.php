<?php
defined('DS') or define('DS', DIRECTORY_SEPARATOR);
/**
 * Файл установки
 * @author Andrew (Panix) Semenov <andrew.panix@gmail.com>
 */
$config = array(
    'basePath' => dirname(__FILE__) . DS . 'protected',
    'language' => 'ru',
    'modules' => array(
        'install',
    ),
    'import' => array(
        'application.components.*',
        'application.components.forms.*',
        'application.components.managers.*',
    ),
    'aliases' => array(
        'mod' => 'application.modules',
        'app' => 'application.components',
    ),
    'components' => array(
        'urlManager' => array(
            'urlFormat' => 'path',
            'showScriptName' => true,
            'rules' => array(
                '/' => 'install/default/index',
               // '/<action:\w+>' => 'install/default/<action>',
            )
        ),
        'cache' => array(
            'class' => 'CDummyCache',
        ),
        'settings' => array('class' => 'app.managers.CManagerSettings'),
        'database' => array('class' => 'app.managers.CManagerDatabase'),
        'tpl' => array('class' => 'app.managers.CManagerTemplater'),
        'languageManager' => array('class' => 'app.managers.CManagerLanguage'),
        'log' => array(
            'class' => 'CLogRouter',
            'enabled' => true,
            'routes' => array(
                array(
                    'class' => 'CFileLogRoute',
                    'levels' => 'error, warning',
                ),
                array(
                    'class' => 'CFileLogRoute',
                    'levels' => 'info',
                    'logFile' => 'info.log',
                    'logPath' => 'log',
                    'enabled' => true,
                ),
                array(
                    'class' => 'CFileLogRoute',
                    'levels' => 'error',
                    'categories' => 'system.db.*',
                    'logFile' => 'sql.log',
                    'logPath' => 'log',
                    'enabled' => true,
                ),
            ),
        ),
    ),
);



if ($_SERVER['REMOTE_ADDR'] == '127.0.0.1') {
    defined('YII_DEBUG') or define('YII_DEBUG', true);
    $yii = dirname(__FILE__) . '/../../framework/yii.php';
} else {
    $yii = dirname(__FILE__) . '/framework/yiilite.php';
}
if(!file_exists($yii))
  die('Please install the framework in the root directory.');

require_once($yii);
Yii::createWebApplication($config)->run();